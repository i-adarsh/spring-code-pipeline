package com.codeops.springcicdpipeline;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCicdPipelineApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringCicdPipelineApplication.class, args);
	}

}
