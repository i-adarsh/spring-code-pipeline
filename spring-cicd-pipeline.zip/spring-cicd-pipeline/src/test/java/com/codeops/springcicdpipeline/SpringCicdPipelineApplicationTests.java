package com.codeops.springcicdpipeline;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCicdPipelineApplicationTests {

	@Test
	void contextLoads() {
	}

}
